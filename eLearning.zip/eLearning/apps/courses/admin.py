from django.contrib import admin
from apps.courses.models import Course


admin.site.register(Course)