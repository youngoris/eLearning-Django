from django.contrib import admin
from apps.teachers.models import Teacher

admin.site.register(Teacher)