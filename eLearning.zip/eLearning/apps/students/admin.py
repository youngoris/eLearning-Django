from django.contrib import admin
from apps.students.models import Student
admin.site.register(Student)